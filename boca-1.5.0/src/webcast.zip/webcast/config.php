<?php

$contest = 1;
$site = 1;

$freezeTime = 240;

?>
